//
//  entryViewController.swift
//  prova-3b1-marceloalemeida
//
//  Created by COTEMIG on 16/08/21.
//

import UIKit

class entryViewController: UIViewController, UITextViewDelegate, UITextFieldDelegate {
    
    @IBOutlet var field: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        field.delegate = self
        
    }
    func textfieldshouldreturn( textfield: UITextField) -> Bool{
        savetask()
        return true
    }
    @IBAction func savetask(){
    }
}

