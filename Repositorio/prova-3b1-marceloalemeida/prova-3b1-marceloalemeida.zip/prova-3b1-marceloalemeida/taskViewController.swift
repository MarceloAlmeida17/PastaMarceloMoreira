//
//  taskViewController.swift
//  prova-3b1-marceloalemeida
//
//  Created by COTEMIG on 16/08/21.
//

import UIKit

class taskViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
