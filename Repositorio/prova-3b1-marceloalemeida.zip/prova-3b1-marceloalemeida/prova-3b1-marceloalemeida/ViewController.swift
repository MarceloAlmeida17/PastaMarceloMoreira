//
//  ViewController.swift
//  prova-3b1-marceloalemeida
//
//  Created by COTEMIG on 16/08/21.
//

import UIKit

class ViewController: UIViewController {
    
    /*/ marcelo moreira mamede de almeida
    11901136
    34
    */
    
    @IBOutlet var tableview:UITableView!
    
    var tasks = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func didtapadd(){
        
        let vc = storyboard?.instantiateViewController(identifier: "entry") as! entryViewController
        vc.title = "novo produto"
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
extension ViewController:UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableview.deselectRow(at: indexPath, animated: true)
    }
}

extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    
        cell.textLabel?.text = tasks[indexPath.row]
        
        return cell
    }
}
